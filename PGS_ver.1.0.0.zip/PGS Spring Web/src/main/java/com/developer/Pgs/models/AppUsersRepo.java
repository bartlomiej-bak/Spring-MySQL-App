package com.developer.Pgs.models;

import org.springframework.data.repository.CrudRepository;

public interface AppUsersRepo extends CrudRepository<AppUsers,Integer>{
}
